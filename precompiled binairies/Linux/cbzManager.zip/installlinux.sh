chmod +x cbzManager
chmod +x cbzManager.desktop
cp cbzManager /usr/local/bin
ln -s /usr/local/bin/cbzManager /usr/bin/cbzManager
cp cbzManager.desktop /usr/share/applications/ 


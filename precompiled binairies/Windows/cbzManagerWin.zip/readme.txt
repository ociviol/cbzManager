if the graphics do not work (no image showing)
install both vcredist_xXX.exe